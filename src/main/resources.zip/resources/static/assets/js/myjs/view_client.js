$(document).ready(function () {
   $("input").attr("disabled","disabled");
});